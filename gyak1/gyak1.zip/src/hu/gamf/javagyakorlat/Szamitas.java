/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.gamf.javagyakorlat;

/**
 *
 * @author 4-11-3-Hallgato
 */
public class Szamitas {

    public Double nettoOsszeg;
    public Double adoErtek;
    public AfaErtek afaErteke;
    public Double bruttoErtek;

    @Override
    public  String toString() {
        return "Szamitas{" + "nettoOsszeg=" + nettoOsszeg + ", adoErtek=" + adoErtek + ", afaErteke=" + afaErteke + ", bruttoErtek=" + bruttoErtek + '}';
    }

    
}
