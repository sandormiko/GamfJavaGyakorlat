/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hu.gamf.javagyakorlat;

/**
 *
 * @author 4-11-3-Hallgato
 */
public class Test {
    
    public void test(){
        GamfJavaGyakorlat gamf = new GamfJavaGyakorlat();
        gamf.nev ="ProfiJavaGyakorlat"; 
    }
}
